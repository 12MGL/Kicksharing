import React from "react";

const App = () => {
  return (
    <div>
      <h1 style={{ color: "#FF8C00" }}>Интерфейс ремонтника</h1>
      <p>Здесь будет основной функционал. Передумал. перенёс в AppRouter.</p>
    </div>
  );
};

export default App;
