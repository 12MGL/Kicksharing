import React from "react";
import "../styles/App.css";

const NotFound = () => {
  return (
    <div className="page" style={{ marginLeft: "260px", padding: "20px" }}>
      <h1>Ошибка 404</h1>
      <br />
      <p>Страница не найдена.</p>
    </div>
  );
};

export default NotFound;
